# car_models > 2024-08-07 8:02am
https://universe.roboflow.com/practice-fr5q7/car_models-s6uma

Provided by a Roboflow user
License: CC BY 4.0

